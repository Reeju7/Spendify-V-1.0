import 'package:flutter/material.dart';

void main() {
  runApp(SpendifyApp());
}

class SpendifyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Spendify',
      theme: ThemeData.dark().copyWith(
        primaryColor: Colors.tealAccent,
        scaffoldBackgroundColor: Color(0xFF121212),
      ),
      home: Scaffold(
        body: Center(child: Text('Spendify V1.0')),
      ),
    );
  }
}
